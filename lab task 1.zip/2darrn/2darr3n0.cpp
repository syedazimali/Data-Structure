#include<iostream>
using namespace std;
int main(){
string arr[4][5]={{"Arif","22-47900-2","3.9","18","male"},
                  {"Nafis","22-47908-2","3.8","19","male"},
                  {"Sinthia","22-47921-2","3.95","20","female"},
                  {"Adnan","22-865-2","3.9","21","male"}};
for(int i=0;i<4;i++){
        for(int j=0;j<5;j++){
    cout<<arr[i][j];

    }
}

}
